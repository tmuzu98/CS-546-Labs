const restaurantData = require("./restaurants");
const reviewsData = require("./reviews");

module.exports = {
	restaurants: restaurantData,
	reviews: reviewsData,
};
