const peopleData = require('./people');
const stocksData = require('./stocks');

module.exports = {
  poeple: peopleData,
  stocks: stocksData
};